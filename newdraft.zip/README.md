# newdraft
a draft plugin for dokuwiki.

I don't know why, but the dokuwiki's auto save mechanism just doesn't work. so I decide to write one in case of suddenly crash situation when editing a page.