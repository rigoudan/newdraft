<?php
/**
 * Options for the newdraft plugin
 */


$meta['filename'] = array('string');
$meta['cachesize'] = array('string');
$meta['interval'] = array('string');
