<?php
/**
 * Default settings for the mdeximg plugin
 *
 * @author  njj <niejijing@gmail.com>
 */

$conf['filename'] = 'cache.doc';
$conf['cachesize'] = '10000';
$conf['interval'] = '5000';
