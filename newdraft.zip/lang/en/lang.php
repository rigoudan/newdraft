<?php
/**
 * English language file for newdraft plugin
 */

 // $lang['e_nodata']         = 'No clipboard data received.';

//Setup VIM: ex: et ts=4 :
