<?php
/**
 * english language file for newdraft plugin
 */

// keys need to match the config setting name
$lang['filename'] = 'specify where to save the article cache data.';
$lang['cachesize'] = 'specify how large the cache will be. It is measured by the number of chars, for example 10000.';
$lang['interval'] = 'specify the time interval between every 2 cache operations. Measured by millseconds, for example: 5000.';



//Setup VIM: ex: et ts=4 :
